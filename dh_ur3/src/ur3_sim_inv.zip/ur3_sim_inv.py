#!/usr/bin/env python


import sys
import numpy as np
import rospy
import moveit_commander
import math
import tf
import geometry_msgs.msg

from std_msgs.msg import Float32
from std_msgs.msg import Float32MultiArray

global position
global p
global q
global r
global xe
global ye
global ze
p = float()
q = float()
r = float()

position = Float32MultiArray()

rospy.init_node('test_ur',anonymous=True)
moveit_commander.roscpp_initialize(sys.argv)

robot = moveit_commander.RobotCommander()
Scene = moveit_commander.PlanningSceneInterface()

group_name = robot.get_group_names()
current_state = robot.get_current_state()
move_group = moveit_commander.MoveGroupCommander(group_name[1])
pose_goal = geometry_msgs.msg.Pose()

rate = rospy.Rate(100)

def get_goal_pose(move_group):
    joint_state = move_group.get_current_pose()
    return joint_state

def callback(data):
    position.data = data.data
    rospy.init_node('test_ur', anonymous=True)
    pose_goal = get_goal_pose(move_group)
    print(pose_goal)
    quat_angle = tf.transformations.euler_from_quaternion([pose_goal.pose.orientation.x, pose_goal.pose.orientation.y, pose_goal.pose.orientation.z, pose_goal.pose.orientation.w])
    euiler_angle = [each*180./math.pi for each in quat_angle]
    print(euiler_angle)
    [p, q, r] = [each*math.pi/180. for each in [0, 90, 90]]

    x, y, z, w = tf.transformations.quaternion_from_euler(p, q, r)
    if abs(position.data[0]) > 0.1:
        [xe] = [pose_goal.pose.position.x-position.data[0]*0.1]
    else:
        [xe] = [pose_goal.pose.position.x]
    if abs(position.data[0]) > 0.1:
        [ye] = [pose_goal.pose.position.y-position.data[1]*0.1]
    else:
        [ye] = [pose_goal.pose.position.y]
    if abs(position.data[0]) > 0.01:
        [ze] = [pose_goal.pose.position.z-position.data[2]*1]
    else:
        [ze] = [pose_goal.pose.position.z]
    pose_goal.pose.position.x = xe
    pose_goal.pose.position.y = ye
    pose_goal.pose.position.z = ze
    pose_goal.pose.orientation.x = x
    pose_goal.pose.orientation.y = y
    pose_goal.pose.orientation.z = z
    pose_goal.pose.orientation.w = w

    move_group.set_pose_target(pose_goal)

    plan = move_group.go(wait=False)

    move_group.stop()
    move_group.clear_pose_targets()

def listener():

    rospy.init_node('test_ur', anonymous=True)

    rospy.Subscriber('range', Float32MultiArray, callback)

    rospy.spin()


if __name__ == '__main__':
    listener()
